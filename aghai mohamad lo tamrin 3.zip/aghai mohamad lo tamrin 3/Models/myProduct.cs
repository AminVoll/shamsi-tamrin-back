namespace aghai_mohamad_lo_tamrin_3.Models
{
    public class myProduct
    {
        [Key]
        public int Id { get; set; }
        [StringLength(100)]
        public string ProductName { get; set; }

        [MaxLength]
        public int Price { get; set; }
        [MaxLength]
        public int ProductCount { get; set; }
        public bool stock { get; set; }
        [Required]
        [StringLength(75)]
        public string Category { get; set; }
    }
}