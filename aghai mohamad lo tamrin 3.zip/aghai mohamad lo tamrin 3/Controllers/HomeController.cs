﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using aghai_mohamad_lo_tamrin_3.Models;

namespace aghai_mohamad_lo_tamrin_3.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        return View();
    }
    public IActionResult productPage()
    {
        List<myProduct> theProduct = new List<myProduct>();

        myProduct product_1 = new myProduct();
        product_1.Id = 1;
        product_1.ProductName = "smal hat nike";
        product_1.Price = 90000;
        product_1.ProductCount = 23;
        product_1.stock = true;
        product_1.Category = "hat";
        theProduct.Add(product_1);
        myProduct product_2 = new myProduct();
        product_2.Id = 2;
        product_2.ProductName = "smart watch";
        product_2.Price = 1300000;
        product_2.ProductCount = 130;
        product_2.stock = false;
        product_2.Category = "watch";
        theProduct.Add(product_2);

        var stockFilter = theProduct.Where(x => x.stock == true).ToList();
        int sumPrice = 0;
        foreach (var items in stockFilter)
        {
            sumPrice += items.Price;
        }
        ViewBag.SumPrices = sumPrice;
        return View(stockFilter);

    }

    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
